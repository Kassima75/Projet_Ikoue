<?php
    //Configuration de la base de données
    $servername = "localhost";
    $username = "kassima";
    $password = "Kassima@123";
    $dbname = "ikoue";

    //Connexion à la base de données 
    $conn = new mysqli($servername, $username, $password, $dbname);

    //Vérifier la connexion 
    if ($conn->connect_error){
        die("La connexion a echoué : " . $conn->connect_error);
    }

    //Récupérer les données du formulaire 
    $nom = isset($_POST['nom']) ? 
    $_POST['nom'] : '';
    $description = isset($_POST['description']) ? 
    $_POST['description'] : '';

    //Vérifier que tous les champs sont remplis 
    if (empty($nom) || empty($description)){
        echo "Tous les champs doivent etre remplis."; 
    }else{
        //Vérifier si l'utilisateur existe déja 
        $sql = "SELECT * FROM tache  WHERE nom = ? AND description = ?;";
        $stmt = $conn->prepare($sql); 
        $stmt->bind_param("ss", $nom, $description);
        $stmt->excute();
        $result = $stmt->get_result(); 
        if ($result->num_row > 0){
            echo "L'utilisateur existe déja.";
        }else{
            //Insérer les données dans la base de données
            $sql = "INSERT INTO tache (nom, description) VALUE (?, ?);";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $nom, $description);
            
            if($stmt->excute()){
                //Rédirection vers la page de confirmation avec les informations de l'utilisateur
                header("location: ../View/ikoue.html");
                exit();
            }else{
                echo "Erreur : " . $sql . "<br>" . $conn->error;
            }
        }
        //Fermer la connexion 
        $stmt->close();
    }
    $conn->close();

?>