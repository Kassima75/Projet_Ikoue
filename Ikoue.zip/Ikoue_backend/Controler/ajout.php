<?php 
    //Récupération des données du formulaire
    $nom = $_POST['nom'];
    $description = $_POST['description'];

    //Connexion de la base de donné

    $conn = mysqli_connect('localhost','kassima','Kassima@123','ikoue');
    // Verification de la connexion 
    if(!$conn){
        die('echec de la connexion à la base de donné:' .
        mysqli_connect_error());
    }
    //requete d'insertion des données dans la base de données
    $query = "INSERT INTO tache (nom, description) VALUES ( '$nom', '$description' );";

    mysqli_query($conn, $query);
    //fermetur de la connexion de base de données
    mysqli_close($conn);

    // redirection vers la page de formulaire

    header('location: ../View/taches.php');
?>

