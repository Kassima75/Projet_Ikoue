<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>confirmation</title>
</head>
<body>
    <h1>informations utilisateur</h1>
    <p><strong>Nom:</strong><?php echo htmlspecialchars($_GET['nom']); ?></p>
    <p><strong>Description:</strong><?php echo htmlspecialchars($_GET['descripton']); ?></p>
    <a href="../View/ikoue.html">Retour au menu</a>
</body>
</html>